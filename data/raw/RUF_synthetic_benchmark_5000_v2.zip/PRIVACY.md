# Privacy and synthesis note

This release is a **masked, synthetic** surrogate of a confidential industrial
spare-parts panel. It is intended to reproduce the *structure* of the real data for
benchmarking, without disclosing the real data.

What is synthetic / masked:
- **Identifiers and categories** (material, plant section/platform, material group,
  description, order, equipment, MRP controller, storage location, etc.) are
  **tokenized** to neutral labels (`COMP_*`, `PLATFORM_*`, `MAT_GROUP_*`, `SYNORD_*`,
  `DESC_*`, `ASSET_*`, …). No real names, codes, or descriptions are present.
- **MAP prices** are drawn from a calibrated price distribution; they are **not** the
  real prices (verified to diverge materially from any real source value).
- **Demand** values are synthetic surrogates **drawn from per-SKU fitted distributions**
  (no real demand value is copied or perturbed). Only aggregate, per-material statistics
  (best-fit count family and its parameters, zero fraction, ADI, CV², Syntetos–Boylan class,
  per-SKU percentile bound, non-stationarity ratio) are used as generation inputs, by design,
  so the benchmark is representative. Because ultra-sparse demand patterns occupy a tiny
  outcome space, an independent parametric draw can coincide with a real series by chance;
  a release audit therefore verifies that **no released series is element-for-element
  identical to any real series** over the release window, resolving any coincidental
  collision by moving one occurrence within its window segment (all audited statistics
  preserved).
- **Per-material fidelity audit.** `synthetic_material_fidelity_5y.csv` publishes each
  material's *target* aggregate signature (zero fraction, ADI, CV², Syntetos–Boylan
  class) — the sampled real template's summary statistics — by design, so the audit is
  independently checkable. The synthetic→real source mapping remains withheld.
- **Inventory planning parameters** (MOQ/EOQ/SOQ/safety stock/reorder points) are
  derived from the synthetic demand path and explicit planning assumptions.

What is intentionally **withheld** (not in this release):
- The synthetic-to-real material **source mapping** (the per-material real source IDs).
- Real donor category labels / distribution-alignment metadata.

This note is **authoritative** and supersedes any earlier price/synthesis wording in
`README.md`: in particular, MAP prices are drawn from a calibrated distribution and
are **not** near-real "jittered donor" values (synthetic prices were verified to
diverge from any real source value by factors ranging well beyond rounding).

Integrity: see `checksums.sha256`. License: CC-BY-4.0.
