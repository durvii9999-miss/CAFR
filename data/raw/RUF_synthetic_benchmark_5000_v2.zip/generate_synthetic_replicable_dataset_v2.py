#!/usr/bin/env python3
"""
generate_synthetic_replicable_dataset_v2.py
===========================================
AUGMENTED PARAMETRIC generator for the RUF public benchmark.

This is the THIRD generator in the family and the one that targets EVERY
published fidelity spec while using the parametric occurrence x size mechanism
the paper (Section 7) describes:

  alt #1  generate_synthetic_replicable_dataset.py   -- vanilla parametric (no
          cross-material dependence; cannot hit lambda_U). KEPT as reference.
  alt #2  build_masked_synthetic_release.py          -- structural perturb-and-
          mask of real series. KEPT as the alternative surrogate.
  THIS    parametric + per-platform latent occurrence factor + 2-gamma sizes +
          regenerate-until-fidelity. Targets all marginal AND dependence specs.

Published targets it must match (real industrial panel, 60-month common window;
from results/paper_d_synthetic_fidelity/2026-05-26/comparison_summary.json):

    marginal  zero-fraction (mean)        0.685
    marginal  dispersion-index (median)   2.058
    marginal  winner-family TVD           <= ~0.05   (gamma_mix2 ~0.45-dominant)
    depend.   mean lambda_U (q=0.90)      0.107
    depend.   mean lambda_L (q=0.10)      0.029
    depend.   copula-family TVD           ~0.08

Mechanism
---------
1. TEMPLATE SAMPLING (Sec.7 stage 1): each synthetic material bootstraps a
   per-material marginal template -- (target zero fraction, non-zero mean,
   non-zero CV^2, ADI, SB class) -- from the REAL per-material feature
   distribution, stratified by Syntetos-Boylan class. Only AGGREGATE per-material
   statistics are read; NO real demand value, identifier, or source mapping is
   used (strictly more private than the perturb-and-mask surrogate).

2. OCCURRENCE x SIZE SYNTHESIS (Sec.7 stage 2) with a DEPENDENCE LAYER:
   - occurrence: latent Gaussian factor model. For material i on platform g,
        Z_it = sqrt(rho_g) * F_{g,t} + sqrt(1-rho_g) * eps_it,
     demand occurs in month t iff Z_it > Phi^{-1}(zero_frac_i). Z_it ~ N(0,1)
     so the marginal occurrence probability (hence zero fraction) is EXACT,
     while the per-platform common factor F_{g,t} makes same-platform materials
     co-occur in the SAME months -> within-platform upper-tail dependence.
     Cross-platform materials share no factor -> independent (median lambda ~ 0).
   - size: 2-component gamma mixture (small routine regime + occasional large
     regime) so the marginal best-fit family is gamma_mix2-dominant, calibrated
     to the template's non-zero mean and CV^2. An optional shared size-shock
     (SIZE_FACTOR_ETA) co-amplifies magnitudes in common-spike months.

3. REGENERATE-UNTIL-FIDELITY (Sec.7 stage 3): each material is regenerated (only
   its idiosyncratic eps; the shared factor F is held) until the realized series
   passes a per-material structural audit (SB class, zero fraction, ADI, CV^2),
   or the best-of-N candidate is kept.

Outputs a material_characterization-style panel (REAL period labels) so it feeds
validate_synthetic_fidelity.py / run_synthetic_full_method_cofr.py /
run_synthetic_instancenorm.py unchanged (just repointed):
    <out>/demand_matrix.csv            material_id + 60 real period columns
    <out>/material_features_full.csv   material_id, mean, zero_fraction, adi,
                                       cv_squared, "Plant Section_<lambda>"
    <out>/material_segments.csv        material_id, syntetos_boylan, method_segment
    <out>/synthetic_map_prices.csv     material_id, map_price
    <out>/generation_manifest.json     knobs + realized marginal summary

The NUDGING LOOP edits the KNOBS block below and re-runs; certify with
validate_synthetic_fidelity.py (repointed) until every spec is in tolerance.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from statistics import NormalDist

import json as _json
import sys as _sys
import numpy as np
import pandas as pd
from scipy.stats import norm as _spnorm  # vectorized ppf for time-varying occurrence thresholds
_sys.path.insert(0, str(Path(__file__).resolve().parent))
import _inverse_cdf_families as _ICF  # exact inverse-CDF samplers for the 8 fitted families

PROJECT = Path(__file__).resolve().parents[2]
REAL_DEMAND = PROJECT / "results/material_characterization/demand_matrix.csv"
REAL_FEAT = PROJECT / "results/material_characterization/material_features_full.csv"
# Per-SKU real parameter catalogue (winning_family + moments + platform), built by
# build_real_param_catalogue.py -- the "additional parameters from real" we match with intent.
CATALOGUE = PROJECT / "results/synthetic_replicable_dataset/_real_param_catalogue.csv"
PLATFORM_COL = "Plant Section_<lambda>"

# Syntetos-Boylan thresholds
ADI_THRESHOLD = 1.32
CV2_THRESHOLD = 0.49

# ---------------------------------------------------------------------------
# KNOBS  --  the nudging loop tunes these
# ---------------------------------------------------------------------------
N_MATERIALS = 5000
N_PERIODS = 60
N_TRAIN = 48               # train 48 / test 12 (matches inversion pipeline)
COLD_START_FRACTION = 0.20

# Non-stationarity layer: reproduces the real per-SKU decline/level-shift (median
# half-ratio 0.65; 47% obsolescent; 96% level-shift) via a mean-normalized time
# profile w_i(t) on the occurrence rate. Preserves marginal zero-fraction while
# front-loading demand -> over-forecasters (Croston/SBA) over-extrapolate the
# decline into the test window (high MASE + high service) -> restores the inversion.
NONSTAT_ENABLE = True
NONSTAT_STRENGTH = 1.0       # 1.0 = full real half-ratio decline; <1 dampens, >1 sharpens
NONSTAT_SIZE_ALPHA = 0.0     # also scale size by w(t)^alpha (0 = decline in frequency only)

# Dependence layer
PLATFORM_LATENT_RHO = 0.20   # within-platform occurrence correlation -> drives lambda_U
SIZE_FACTOR_ETA = 0.15       # mean-preserving size co-movement exp(eta*F - eta^2/2) -> lifts lambda_L

# Size model: the non-zero-size LAW is selected per material by the winning_family
# sampled from the real catalogue, so the best-fit-family mix matches real BY
# CONSTRUCTION (real proportions, conditioned on the real per-SKU moments).
GAMMA_MIX_W_LARGE = 0.30     # gamma_mix2 law: fraction in the large regime (clearer bimodality ->
GAMMA_MIX_LARGE_MULT = 4.5   # gamma_mix2 law: large/small mean ratio   wins gamma_mix2 over cp_gamma)
GAMMA_SMALL_SHAPE = 1.7      # gamma_mix2 law: gamma shape (k) for the routine regime
GAMMA_LARGE_SHAPE = 1.1      # gamma_mix2 law: gamma shape (k) for the lumpy regime
DISCRETE_CV2_CAP = 1.8       # cap CV^2 for NB/zinb/hurdle so they stay discrete (not lognormal-tailed)
# Non-inflated count families: generate natural count-zeros (no occurrence inflation)
# so the fitter re-wins poisson/negbinom instead of the zero-inflated zip/zinb.
COUNT_NATIVE = {"poisson"}   # poisson's integer inverse-CDF under-disperses -> native path
COUNT_NATIVE_NB_R = 4.0      # NB size (dispersion) for the native path

# Generation mode for the marginal:
#   "copula"     -- draw each material from its real SKU's EXACT fitted distribution
#                   (inverse-CDF on a Gaussian-copula uniform); rate=1 in train -> exact
#                   marginal (TVD -> noise floor), declined in test -> keeps inversion.
#   "lawmatched" -- family-matched-law approximation everywhere (TVD ~0.060).
#   "copula"     -- HYBRID per-family routing: exact inverse-CDF for the families whose MLE fit
#                   is stable on sparse data (COPULA_FAMILIES), law-matched 2-gamma for the
#                   underdetermined gamma mixture / compound-gamma, count-native for poisson.
GEN_MODE = "copula"
DEMAND_CAP = 8000            # global ceiling (~ real-panel max 7207); last-resort blow-up guard
# Per-material cap = (real SKU's CAP_PERCENTILE-th demand percentile) x CAP_HEADROOM. Data-driven,
# dynamic per material, dataset-agnostic (recomputed from whatever real panel feeds the catalogue),
# and robust to a lone extremum (vs. using the raw max). Bounds the heavy MLE inverse-CDF tail to
# the empirical range while leaving the legitimate bulk untouched.
CAP_PERCENTILE = 99          # (documented; the catalogue column is real_p{CAP_PERCENTILE})
CAP_HEADROOM = 3.0
# DETERMINACY-BASED routing (NOT family-based). Diagnostic finding: a fitted marginal
# over-disperses when its MLE is UNDERDETERMINED -- i.e. when observations-per-parameter is low
# -- not because of the family itself. (gamma_mix2 dispersion ratio: 5.0 at 4-8 obs -> 1.18 at
# 26+ obs; the heavy families just carry MORE parameters so they need MORE data.) So we trust the
# exact inverse-CDF when n_pos/n_params >= threshold, and fall back to the moment-matched
# law-matched path when the fit is underdetermined. Generalises to any dataset.
PARAM_COUNT = {"poisson": 1, "negbinom": 2, "zip": 2, "zinb": 3, "hurdle_nb": 3,
               "compound_poisson_gamma": 3, "compound_poisson_lognormal": 3, "gamma_mix2": 6}
DETERMINACY_THRESHOLD = 3.5   # min observations-per-parameter to trust the exact inverse-CDF

# Regenerate-until-fidelity audit
MAX_REGEN_ATTEMPTS = 10
AUDIT_ZEROFRAC_TOL = 0.07
AUDIT_CV2_REL_TOL = 0.60

# MAP price (right-skewed; barely matters for the COFR proxy)
PRICE_MU_LN, PRICE_SIGMA_LN = 3.70, 1.60

_NORM = NormalDist()


# ---------------------------------------------------------------------------
def classify_sbc(adi: float, cv2: float) -> str:
    if not np.isfinite(adi):
        return "smooth"
    if adi >= ADI_THRESHOLD:
        return "lumpy" if cv2 >= CV2_THRESHOLD else "intermittent"
    return "erratic" if cv2 >= CV2_THRESHOLD else "smooth"


def classify_sparsity(zf: float) -> str:
    if zf >= 0.80:
        return "ultra_sparse"
    if zf >= 0.60:
        return "sparse"
    if zf >= 0.30:
        return "medium_density"
    return "dense"


def load_catalogue() -> tuple[pd.DataFrame, list[str]]:
    """Load the real per-SKU parameter catalogue (winning_family + moments +
    platform). Sampling whole rows preserves the JOINT real distribution of
    family x sparsity x size x platform -> marginal family-mix matches by
    construction. Falls back to raw features if the catalogue is absent."""
    dcols = [c for c in pd.read_csv(REAL_DEMAND, nrows=0).columns if c != "material_id"]
    period_labels = dcols[:N_PERIODS]

    if CATALOGUE.exists():
        cat = pd.read_csv(CATALOGUE)
        cat["platform"] = cat["platform"].fillna("PLATFORM_UNK").astype(str)
    else:  # fallback: raw features, family unknown -> default to gamma_mix2 law
        feat = pd.read_csv(REAL_FEAT)
        cat = pd.DataFrame({
            "zero_fraction": pd.to_numeric(feat["zero_fraction"], errors="coerce"),
            "non_zero_mean": pd.to_numeric(feat["non_zero_mean"], errors="coerce"),
            "non_zero_cv2": pd.to_numeric(feat["non_zero_cv_squared"], errors="coerce"),
            "adi": pd.to_numeric(feat["adi"], errors="coerce"),
            "platform": feat[PLATFORM_COL].fillna("PLATFORM_UNK").astype(str),
            "winning_family": "gamma_mix2",
        })
    cat = cat.dropna(subset=["zero_fraction", "non_zero_mean"])
    cat = cat[(cat["non_zero_mean"] > 0) & (cat["zero_fraction"] >= 0) & (cat["zero_fraction"] < 1)]
    cat["non_zero_cv2"] = cat["non_zero_cv2"].fillna(1.0)
    cat["sbc"] = [classify_sbc(a, c) for a, c in
                  zip(cat["adi"].fillna(np.inf), cat["non_zero_cv2"].fillna(0.0))]
    return cat.reset_index(drop=True), period_labels


def draw_sizes(n: int, target_mean: float, target_cv2: float, family: str,
               rng: np.random.Generator) -> np.ndarray:
    """Per-material non-zero-size draw whose LAW is matched to the real SKU's
    winning count-family. Occurrence (hence the zero structure) is handled by the
    latent-factor threshold, so this governs only the strictly-positive sizes."""
    if n == 0:
        return np.zeros(0)
    m = max(target_mean, 1e-6)
    cv2 = target_cv2 if np.isfinite(target_cv2) and target_cv2 > 0 else 1.0

    if family in ("poisson", "zip"):
        # low-dispersion integer sizes >= 1
        return 1.0 + rng.poisson(max(m - 1.0, 0.05), size=n)
    if family in ("negbinom", "zinb", "hurdle_nb"):
        # over-dispersed integer sizes >= 1: NB with var = cv2*m^2.
        # Cap CV^2 so the counts stay NB-shaped (not lognormal-tailed) and the
        # fitter re-wins the discrete count family instead of compound-lognormal.
        cv2 = min(cv2, DISCRETE_CV2_CAP)
        denom = cv2 * m - 1.0
        if denom <= 0.2:
            return 1.0 + rng.poisson(max(m - 1.0, 0.05), size=n)
        r = max(0.05, m / denom)
        p = r / (r + m)
        return 1.0 + rng.negative_binomial(r, p, size=n)
    if family == "compound_poisson_gamma":
        shape = max(0.15, 1.0 / cv2)
        return rng.gamma(shape, m / shape, size=n)
    if family == "compound_poisson_lognormal":
        sig = float(np.sqrt(np.log1p(cv2)))
        return rng.lognormal(np.log(m) - sig * sig / 2.0, sig, size=n)
    # gamma_mix2 (dominant family): 2-component gamma mixture
    w = GAMMA_MIX_W_LARGE
    m_s = m / ((1 - w) + w * GAMMA_MIX_LARGE_MULT)
    m_l = m_s * GAMMA_MIX_LARGE_MULT
    pick_large = rng.random(n) < w
    out = np.empty(n)
    n_l = int(pick_large.sum())
    if n - n_l:
        out[~pick_large] = rng.gamma(GAMMA_SMALL_SHAPE, m_s / GAMMA_SMALL_SHAPE, size=n - n_l)
    if n_l:
        out[pick_large] = rng.gamma(GAMMA_LARGE_SHAPE, m_l / GAMMA_LARGE_SHAPE, size=n_l)
    return out


def realized_stats(series: np.ndarray) -> dict:
    n = len(series)
    nz = series[series > 0]
    zf = float((series == 0).mean())
    n_nz = int(len(nz))
    adi = float(n / n_nz) if n_nz else np.inf
    cv2 = float((nz.std(ddof=1) / nz.mean()) ** 2) if n_nz >= 2 and nz.mean() > 0 else 0.0
    return {"zero_fraction": zf, "n_nonzero": n_nz, "adi": adi, "cv2": cv2,
            "mean": float(series.mean()), "sbc": classify_sbc(adi, cv2)}


def generate_panel(seed: int) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    rng = np.random.default_rng(seed)
    cat, period_labels = load_catalogue()

    # --- sample whole real catalogue rows (Sec.7 stage 1): each synthetic material
    #     inherits a real SKU's (winning_family, zero-frac, size, CV^2, platform) ---
    idx = rng.integers(0, len(cat), size=N_MATERIALS)
    mt = cat.iloc[idx].reset_index(drop=True)
    platforms = mt["platform"].to_numpy()
    families = mt["winning_family"].to_numpy()
    # parse each material's real fitted params (for the copula/inverse-CDF marginal path)
    if "fit_params" in mt.columns:
        params_list = [(_json.loads(fp) if isinstance(fp, str) and fp.strip().startswith("{") else None)
                       for fp in mt["fit_params"]]
    else:
        params_list = [None] * N_MATERIALS
    # per-material percentile truncation bound (internal catalogue stat; never released):
    # real SKU p99 x headroom, capped by the global ceiling. Bounds the heavy MLE inverse-CDF
    # tail to the empirical range.
    if "real_p99" in mt.columns:
        cap_bound = pd.to_numeric(mt["real_p99"], errors="coerce").fillna(DEMAND_CAP).clip(lower=1).to_numpy()
        cap_bound = np.minimum(cap_bound * CAP_HEADROOM, DEMAND_CAP)
    else:
        cap_bound = np.full(N_MATERIALS, DEMAND_CAP, dtype=float)
    # fit determinacy per material = observations-per-parameter (drives copula-vs-lawmatched routing)
    n_pos_est = np.round((1.0 - pd.to_numeric(mt["zero_fraction"], errors="coerce").fillna(0.7).to_numpy())
                         * N_TRAIN)
    n_per_param = n_pos_est / np.array([float(PARAM_COUNT.get(f, 3)) for f in families])
    is_cold = np.zeros(N_MATERIALS, dtype=bool)
    is_cold[rng.choice(N_MATERIALS, size=int(round(N_MATERIALS * COLD_START_FRACTION)), replace=False)] = True

    # --- non-stationarity time profile (Sec.7 stage 2): mean-normalized w_i(t) from
    #     the real per-SKU half-ratio, so demand declines/grows the way real demand does ---
    if NONSTAT_ENABLE and "half_ratio" in mt.columns:
        half_ratio = pd.to_numeric(mt["half_ratio"], errors="coerce").fillna(1.0).to_numpy()
    else:
        half_ratio = np.ones(N_MATERIALS)
    half_ratio = np.clip(half_ratio, 0.08, 12.0) ** NONSTAT_STRENGTH
    half_ratio[is_cold] = np.maximum(half_ratio[is_cold], 1.0)   # new/cold-start parts don't decline
    texp = np.linspace(0.0, 1.0, N_PERIODS)
    Wprof = np.power(half_ratio[:, None], texp[None, :])          # geometric trend, w(0)=1 -> w(T)=half_ratio
    Wprof = Wprof / Wprof.mean(axis=1, keepdims=True)             # mean-normalize -> preserves zero-fraction
    # copula path rate: FLAT (=1) over the TRAIN window so the fitted marginal F_i is
    # reproduced exactly (no rate-mixture over-dispersion); a single declined level over
    # the TEST window (a level-shift, matching the 96%-level-shift real panel) so over-
    # forecasters still over-extrapolate -> keeps the inversion.
    Rate = np.ones((N_MATERIALS, N_PERIODS))
    Rate[:, N_TRAIN:] = np.clip(half_ratio, 0.1, 3.0)[:, None]

    # --- per-platform per-period latent common factor F[g,t] (dependence layer) ---
    uniq_plat = {p: i for i, p in enumerate(np.unique(platforms))}
    plat_idx = np.array([uniq_plat[p] for p in platforms])
    n_plat = len(uniq_plat)
    F = rng.standard_normal((n_plat, N_PERIODS))           # shared factor per platform/month
    rho = PLATFORM_LATENT_RHO
    sqrt_rho, sqrt_1mrho = np.sqrt(rho), np.sqrt(1.0 - rho)

    rows = np.zeros((N_MATERIALS, N_PERIODS))
    audit_pass = np.zeros(N_MATERIALS, dtype=bool)
    attempts_used = np.ones(N_MATERIALS, dtype=int)

    for i in range(N_MATERIALS):
        zf_t = float(mt.at[i, "zero_fraction"])
        nz_mean_t = float(mt.at[i, "non_zero_mean"])
        nz_cv2_t = float(mt.at[i, "non_zero_cv2"]) if np.isfinite(mt.at[i, "non_zero_cv2"]) else 1.0
        # time-varying occurrence threshold: P(occur at t) = (1-zf)*w_i(t), mean = 1-zf
        p_occ = np.clip((1.0 - zf_t) * Wprof[i], 1e-4, 0.999)
        thr_t = _spnorm.ppf(1.0 - p_occ)                      # per-period threshold (vectorized)
        Fg = F[plat_idx[i]]
        best, best_score, best_stats = None, np.inf, None
        for attempt in range(MAX_REGEN_ATTEMPTS):
            eps = rng.standard_normal(N_PERIODS)
            Z = sqrt_rho * Fg + sqrt_1mrho * eps
            if (GEN_MODE == "copula" and params_list[i] is not None
                    and families[i] != "poisson" and n_per_param[i] >= DETERMINACY_THRESHOLD):
                # exact marginal: inverse-CDF of the real SKU's fitted distribution on the
                # Gaussian-copula uniform (rate=1 over train -> marginal == fitted F). Used only
                # when the fit is WELL-DETERMINED (enough observations per parameter); otherwise
                # the heavy MLE tail would over-disperse -> fall through to law-matched.
                series = _ICF.quantile(families[i], params_list[i],
                                       _spnorm.cdf(Z), Rate[i]).astype(float)
                if is_cold[i]:
                    series[:N_TRAIN] = 0.0
            elif families[i] in COUNT_NATIVE:
                # non-inflated count process: zeros arise from the count law itself
                rate = max((1.0 - zf_t) * nz_mean_t, 1e-3) * Wprof[i]
                if families[i] == "poisson":
                    series = rng.poisson(rate).astype(float)
                else:
                    pe = COUNT_NATIVE_NB_R / (COUNT_NATIVE_NB_R + np.maximum(rate, 1e-6))
                    series = rng.negative_binomial(COUNT_NATIVE_NB_R, pe).astype(float)
                if is_cold[i]:
                    series[:N_TRAIN] = 0.0
            else:
                occ = Z > thr_t
                if is_cold[i]:
                    occ[:N_TRAIN] = False
                series = np.zeros(N_PERIODS)
                k = int(occ.sum())
                if k:
                    sizes = draw_sizes(k, nz_mean_t, nz_cv2_t, families[i], rng)
                    if SIZE_FACTOR_ETA > 0:
                        # mean-preserving symmetric co-movement: co-large in high-F months,
                        # co-small in low-F months -> lifts BOTH tail-dependence ends
                        sizes = sizes * np.exp(SIZE_FACTOR_ETA * Fg[occ] - 0.5 * SIZE_FACTOR_ETA ** 2)
                    if NONSTAT_SIZE_ALPHA > 0:
                        sc = Wprof[i][occ] ** NONSTAT_SIZE_ALPHA
                        sizes = sizes * sc / sc.mean()
                    series[occ] = np.maximum(1, np.round(sizes))
            # universal per-material percentile cap (data-driven, dataset-agnostic): bounds any
            # family's heavy tail to the empirical range, decoupling family-identity tuning from
            # dispersion control.
            np.minimum(series, cap_bound[i], out=series)
            st = realized_stats(series)
            # audit score (lower better): zero-frac + cv2 + SB-class match
            score = abs(st["zero_fraction"] - zf_t)
            score += 0.3 * abs(st["cv2"] - nz_cv2_t) / max(nz_cv2_t, 0.5)
            if st["sbc"] != mt.at[i, "sbc"]:
                score += 0.5
            ok = (abs(st["zero_fraction"] - zf_t) <= AUDIT_ZEROFRAC_TOL and
                  st["sbc"] == mt.at[i, "sbc"])
            if score < best_score:
                best, best_score, best_stats = series, score, st
                attempts_used[i] = attempt + 1
            if ok:
                audit_pass[i] = True
                break
        rows[i] = best

    # --- assemble outputs ---
    new_ids = [f"SYN5Y_{i:05d}" for i in range(1, N_MATERIALS + 1)]
    demand = pd.DataFrame(rows.astype(int), columns=period_labels)
    demand.insert(0, "material_id", new_ids)

    feats = []
    segs = []
    for i, mid in enumerate(new_ids):
        st = realized_stats(rows[i])
        feats.append({
            "material_id": mid, "mean": st["mean"], "zero_fraction": st["zero_fraction"],
            "adi": st["adi"] if np.isfinite(st["adi"]) else N_PERIODS,
            "cv_squared": st["cv2"], PLATFORM_COL: platforms[i],
        })
        sp = classify_sparsity(st["zero_fraction"])
        segs.append({"material_id": mid, "syntetos_boylan": st["sbc"],
                     "method_segment": f"{st['sbc']}+{sp}"})
    features = pd.DataFrame(feats)
    segments = pd.DataFrame(segs)

    realized = {
        "n_materials": N_MATERIALS, "n_periods": N_PERIODS,
        "zero_fraction_mean": float((rows == 0).mean()),
        "per_sku_zero_fraction_mean": float(features["zero_fraction"].mean()),
        "per_sku_zero_fraction_median": float(features["zero_fraction"].median()),
        "dispersion_index_median": float(_dispersion_median(rows)),
        "sbc_mix": segments["syntetos_boylan"].value_counts(normalize=True).round(4).to_dict(),
        "audit_pass_rate": float(audit_pass.mean()),
        "mean_attempts": float(attempts_used.mean()),
        "n_platforms": int(n_plat),
    }
    # INTERNAL ONLY (never released): which real catalogue SKU each synthetic material drew its
    # template from. Used by the release builder to compute the per-material fidelity target_*
    # (real SKU's aggregate signature) — the same privacy posture as the structural builder, which
    # tracks source_demand_material_id internally and releases only the aggregate target_* stats.
    source_map = pd.DataFrame({"material_id": new_ids,
                               "source_catalogue_id": mt["material_id"].astype(str).to_numpy(),
                               "attempts_used": attempts_used})
    return demand, features, segments, realized, source_map


def _dispersion_median(rows: np.ndarray) -> float:
    tr = rows[:, :N_TRAIN].astype(float)
    mu = tr.mean(axis=1)
    var = tr.var(axis=1)
    disp = np.where(mu > 0, var / np.maximum(mu, 1e-9), np.nan)
    return float(np.nanmedian(disp))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()

    out = Path(args.out) if args.out else (
        PROJECT / "results/synthetic_replicable_dataset/2026-06-09_material_characterization_5000_parametric_v2")
    out.mkdir(parents=True, exist_ok=True)

    demand, features, segments, realized, source_map = generate_panel(args.seed)
    demand.to_csv(out / "demand_matrix.csv", index=False)
    features.to_csv(out / "material_features_full.csv", index=False)
    segments.to_csv(out / "material_segments.csv", index=False)
    source_map.to_csv(out / "_source_catalogue_map.csv", index=False)  # INTERNAL, not for release

    rng = np.random.default_rng(args.seed + 1000)
    prices = pd.DataFrame({
        "material_id": demand["material_id"],
        "map_price": np.round(np.maximum(1.0, rng.lognormal(PRICE_MU_LN, PRICE_SIGMA_LN, len(demand))), 2),
    })
    prices.to_csv(out / "synthetic_map_prices.csv", index=False)

    manifest = {
        "generator": "generate_synthetic_replicable_dataset_v2.py",
        "seed": args.seed,
        "knobs": {
            "PLATFORM_LATENT_RHO": PLATFORM_LATENT_RHO, "SIZE_FACTOR_ETA": SIZE_FACTOR_ETA,
            "GAMMA_MIX_W_LARGE": GAMMA_MIX_W_LARGE, "GAMMA_MIX_LARGE_MULT": GAMMA_MIX_LARGE_MULT,
            "GAMMA_SMALL_SHAPE": GAMMA_SMALL_SHAPE, "GAMMA_LARGE_SHAPE": GAMMA_LARGE_SHAPE,
            "COLD_START_FRACTION": COLD_START_FRACTION, "N_TRAIN": N_TRAIN,
        },
        "realized": realized,
        "targets": {"zero_fraction_mean": 0.685, "dispersion_index_median": 2.058,
                    "mean_lambda_upper": 0.107, "mean_lambda_lower": 0.029},
    }
    (out / "generation_manifest.json").write_text(json.dumps(manifest, indent=2))

    print(f"[v2] wrote -> {out}")
    print(json.dumps(realized, indent=2))


if __name__ == "__main__":
    main()
