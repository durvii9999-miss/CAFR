# Reproducing the paper's findings on the public panel

This release is the **synthetic, fidelity-certified surrogate** of the confidential
industrial spare-parts panel used in *"Accuracy Is Not Service."* It lets
anyone re-run the paper's decision-aware analysis without access to the real data.

License **CC-BY-4.0** · distributed from the paper's repository. See `DATASHEET.md` for the
full datasheet and `PRIVACY.md` for the privacy model.

## What ships here
| File | Contents |
|------|----------|
| `synthetic_demand_matrix_5y.csv` | 5,000 materials × 60 monthly demand cells |
| `synthetic_full_data_generic_5y.csv` | multi-item order lines (synthetic disaggregation of the demand panel) |
| `synthetic_map_prices.csv` | moving-average unit prices |
| `synthetic_material_{metadata,catalog,context}_5y.csv` | per-material demand stats + neutral attributes |
| `synthetic_inventory_planning_params_5y.csv` | lead times, review periods, policy inputs |
| `synthetic_material_fidelity_5y.csv` | per-material fidelity-audit pass record |
| `period_lookup_5y.csv` | period index → month |
| `generate_synthetic_replicable_dataset_v2.py`, `_inverse_cdf_families.py` | the generator (procedural transparency; see below) |
| `DATASHEET.md`, `PRIVACY.md`, `CITATION.cff`, `checksums.sha256` | metadata + integrity |

## Expected results on this panel (full 38-method roster)
Running the audited, no-fallback protocol (rolling-origin, relative-to-Naive MASE;
common base-stock order-up-to; per-material service/period-fill proxy at the 80% target)
reproduces the paper's three headline findings **directionally** on the synthetic panel:

1. **Leaderboard.** The accuracy leaders are the foundation models and the weighted
   moving average — **WMA, TimesFM, and Chronos-Bolt occupy MASE ranks 1–4**.
2. **Accuracy–service inversion.** MASE rank and per-material service rank are **strongly
   negatively correlated, ρ ≈ −0.47 at the 80% target** (ρ −0.41…−0.50 at every service
   level; Spearman p < 0.005, n = 38; 95% CI [−0.76, −0.10] excludes zero). The four most accurate methods
   sit in the bottom third on service; the over-forecasting specialists (Croston, SBA, ADIDA,
   Moirai) hold the top service ranks. (This replication scores the **per-material** metric;
   the bundled order lines are a synthetic disaggregation of the demand panel, not the
   operator's contract order log, over which the real panel's order-level value is
   ρ = −0.555 across 20,330 orders. The like-for-like industrial comparator is the
   per-material ρ = −0.58.)
3. **Zero-cost InstanceNorm fix.** Re-centering Chronos-2 on non-zero-conditional
   statistics lifts item-level fill rate by **+22.7 to +28.2 pp** across service targets
   (≈ 74% of materials show the > 2× centering artifact), at zero training cost.

The synthetic per-material inversion reproduces **strongly** (ρ ≈ −0.47, roughly 80% of the
industrial panel's like-for-like per-material −0.58 and far beyond the structural surrogate's
−0.31), with the same sign and mechanism — which is the point of a *certified* surrogate.

## How to run it
The benchmark pipeline lives in the paper's public code repository,
https://github.com/sfcheng-research/icdm-2026 (not in this bundle). Unpack this
release to the path the repository's `REPRODUCE.md` specifies, then run from `src/`:

```bash
# full 38-method benchmark + accuracy-service inversion on this panel, gated at 38/38
bash scripts/10_experiments/run_synthetic_38_v2.sh
# the zero-cost InstanceNorm (non-zero re-centering) correction on Chronos-2
SYNTH_PANEL=results/synthetic_replicable_dataset/v2_panel \
python scripts/10_experiments/run_synthetic_instancenorm.py
```

Environments are described in the repository's `docs/ENVIRONMENT_GUIDE.md` (a single
main env covers classical/ML/boosting/neural/Chronos/Moirai/TBATS; Prophet and TimesFM
each use a small dedicated conda env). Fixed seed = 42 throughout.

## About the generator
`generate_synthetic_replicable_dataset_v2.py` (+ `_inverse_cdf_families.py`) is included for
**full procedural transparency**: it documents the parametric occurrence×size model — each
material drawn from a real SKU's fitted count-family by inverse-CDF, routed by fit determinacy
(observations-per-parameter) — the per-platform latent factor for cross-material tail
dependence, the per-SKU non-stationarity (decline/obsolescence), and the **per-material
regenerate-until-fidelity audit** (Syntetos–Boylan class, zero fraction, CV²). It draws each
material from a real SKU's *fitted parameter template*, so re-running the generator itself
requires the confidential per-SKU catalogue and is **not** publicly executable — the certified
synthetic panel in this release is the runnable artifact. Fidelity vs. the real panel: marginal
family-mix TVD 0.051, copula-family-mix TVD 0.068 (`DATASHEET.md`).
