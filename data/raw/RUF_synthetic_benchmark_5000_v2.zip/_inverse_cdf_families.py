#!/usr/bin/env python3
"""Inverse-CDF (quantile) samplers for the 8 Paper-D count families, so the v2
generator can draw each synthetic material from its real SKU's EXACT fitted
distribution via a Gaussian-copula uniform. `rate` (per-period array) scales the
intensity for non-stationarity (1.0 in train -> exact marginal; <1 in test ->
decline). Returns integer demand. Mirrors the CDFs in fit_marginal_catalogue.py."""
import numpy as np
from scipy import stats as sps


def _nb_p_from_mean(r, mean):
    return r / (r + np.maximum(mean, 1e-6))


def quantile(family, P, u, rate=1.0):
    # clip the copula uniform away from 0/1 so heavy-tail inverse-CDFs cannot blow up
    u = np.clip(np.asarray(u, dtype=float), 1e-5, 1.0 - 1e-5)
    rate = rate * np.ones_like(u)

    if family == "poisson":
        return sps.poisson.ppf(u, np.maximum(P["lambda"], 1e-6) * rate)

    if family == "negbinom":
        r = max(P["r"], 1e-3)
        mean0 = r * (1 - P["p"]) / max(P["p"], 1e-6)
        return sps.nbinom.ppf(u, r, _nb_p_from_mean(r, mean0 * rate))

    if family in ("zip", "zinb"):
        pi = P["pi"]
        out = np.zeros_like(u)
        m = u > pi
        upos = (u[m] - pi) / (1 - pi)
        if family == "zip":
            out[m] = sps.poisson.ppf(upos, np.maximum(P["lambda"], 1e-6) * rate[m])
        else:
            r = max(P["r"], 1e-3)
            mean0 = r * (1 - P["p"]) / max(P["p"], 1e-6)
            out[m] = sps.nbinom.ppf(upos, r, _nb_p_from_mean(r, mean0 * rate[m]))
        return out

    if family == "hurdle_nb":
        r, p = max(P["r"], 1e-3), P["p"]
        pocc = np.clip(P["p_occ"] * rate, 0, 1)
        nb_p0 = sps.nbinom.pmf(0, r, p)
        out = np.zeros_like(u)
        thr = 1 - pocc
        m = u > thr
        upos = (u[m] - thr[m]) / np.maximum(pocc[m], 1e-9)
        out[m] = np.maximum(1, sps.nbinom.ppf(nb_p0 + upos * (1 - nb_p0), r, p))
        return out

    if family in ("compound_poisson_gamma", "compound_poisson_lognormal"):
        pocc = np.clip(P["p_occ"] * rate, 0, 1)
        out = np.zeros_like(u)
        thr = 1 - pocc
        m = u > thr
        upos = (u[m] - thr[m]) / np.maximum(pocc[m], 1e-9)
        if family == "compound_poisson_gamma":
            sz = sps.gamma.ppf(upos, a=max(P["alpha"], 1e-3), scale=max(P["beta"], 1e-6))
        else:
            sz = sps.lognorm.ppf(upos, s=max(P["sigma"], 1e-3), scale=float(np.exp(P["mu"])))
        out[m] = np.maximum(1, np.round(sz))
        return out

    if family == "gamma_mix2":
        pocc = np.clip(P["p_occ"] * rate, 0, 1)
        out = np.zeros_like(u)
        thr = 1 - pocc
        m = u > thr
        upos = (u[m] - thr[m]) / np.maximum(pocc[m], 1e-9)
        w = P["w"]
        a1, b1 = max(P["a1"], 1e-3), max(P["b1"], 1e-6)
        a2, b2 = max(P["a2"], 1e-3), max(P["b2"], 1e-6)
        hi = max(float(sps.gamma.ppf(0.999, a1, scale=b1)),
                 float(sps.gamma.ppf(0.999, a2, scale=b2)), 2.0)
        grid = np.linspace(0.0, hi, 512)
        cdf = w * sps.gamma.cdf(grid, a=a1, scale=b1) + (1 - w) * sps.gamma.cdf(grid, a=a2, scale=b2)
        sz = np.interp(upos, cdf, grid)
        out[m] = np.maximum(1, np.round(sz))
        return out

    raise ValueError(f"unknown family {family}")
