# Synthetic Spare-Parts Demand Benchmark (masked; 5,000 materials, 5 years) — v2

A fully synthetic, masked replication benchmark for intermittent spare-parts demand
forecasting and inventory evaluation. It reproduces the *structure* of a confidential
industrial panel **without disclosing any real data**: all identifiers and categorical
fields are tokenized to neutral labels, MAP prices are drawn from a calibrated
distribution (not real prices), and demand values are synthetic surrogates. See
`PRIVACY.md`.

5,000 synthetic materials × 60 monthly periods (2018-09 … 2023-08).

> **v2 note.** After the paper was submitted, the generation technique received a small
> patch to better reproduce the real data: a fully parametric occurrence×size generator
> (each material drawn from a real SKU's fitted count-family by inverse-CDF, with a per-platform
> latent factor for cross-material tail dependence and a per-SKU non-stationarity). The
> **volume and schema are unchanged**; only the generation method and the fidelity scores differ.
> See `DATASHEET.md`.

## Files
| File | Contents |
|---|---|
| `synthetic_demand_matrix_5y.csv` | monthly demand panel (`material_id` × month) |
| `synthetic_material_metadata_5y.csv` | per-material demand statistics (Syntetos–Boylan class, ADI, CV², run-lengths, …) |
| `synthetic_material_catalog_5y.csv` | selection-ready catalogue (statistics, activity bands, fidelity pass) |
| `synthetic_context_materials_5y.csv` | per-material categorical context (neutral `category_*` labels) |
| `synthetic_full_data_generic_5y.csv` | order-line event log with neutral column names |
| `synthetic_map_prices.csv` | synthetic MAP prices (`material_id`, `map_price`) |
| `synthetic_inventory_planning_params_5y.csv` | derived inventory planning parameters |
| `synthetic_material_fidelity_5y.csv` | per-material fidelity audit (real source IDs withheld) |
| `period_lookup_5y.csv` | period index → calendar month |
| `generate_synthetic_replicable_dataset_v2.py`, `_inverse_cdf_families.py` | the generator (procedural transparency; needs the confidential catalogue to run) |
| `DATASHEET.md`, `REPRODUCE.md`, `PRIVACY.md`, `CITATION.cff`, `.zenodo.json`, `checksums.sha256` | metadata + integrity |

All column names are generic or neutral; none reproduce the original system's schema.

License: **CC-BY-4.0**. Accompanies the paper *"Accuracy Is Not Service: A Decision-Aware Benchmark for Intermittent-Demand Forecasting."*
