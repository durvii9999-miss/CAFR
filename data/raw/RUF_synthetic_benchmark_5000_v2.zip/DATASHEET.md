# Datasheet — Synthetic Spare-Parts Demand Benchmark (v2, parametric)

Following *Datasheets for Datasets* (Gebru et al., 2021). Accompanies the paper
*"Accuracy Is Not Service: A Decision-Aware Benchmark for Intermittent-Demand Forecasting."*
License **CC-BY-4.0**.

> **Note on this release (v2).** After the paper was submitted, the synthetic-data
> generation technique received a small patch to better reproduce the real data: the
> generator is now a fully parametric occurrence×size model (described below) that draws each
> material from a real SKU's fitted distribution, adds the real per-SKU non-stationarity, and
> reproduces cross-material tail dependence. The **volume and schema are unchanged** (5,000
> materials × 60 months; identical files/columns). Only the **generation method** and the
> **fidelity (similarity) scores** differ from the earlier release. The accuracy–service
> inversion, the leaderboard, and the InstanceNorm fix all still reproduce on this panel.

## Motivation
- **Why created.** There is no public, *decision-aware* benchmark for **intermittent**
  spare-parts demand: existing forecasting benchmarks (M4/M5) are structurally smooth
  retail/macro series, and the industrial panels where intermittency actually bites are
  confidential. This dataset is a fidelity-certified synthetic surrogate that lets the
  community reproduce and extend decision-aware evaluation (forecast → inventory policy →
  service) on realistic sparse demand without any confidential data.
- **Created by.** Authors at the School of Computing and Information Systems, Singapore
  Management University.

## Composition
- **Instances.** 5,000 synthetic materials × 60 monthly periods (2018-09 … 2023-08), plus a
  multi-item order log, MAP unit prices, per-material demand statistics, and a per-material
  fidelity audit. Files: `synthetic_demand_matrix_5y.csv`, `synthetic_material_metadata_5y.csv`,
  `synthetic_material_catalog_5y.csv`, `synthetic_context_materials_5y.csv`,
  `synthetic_full_data_generic_5y.csv` (order lines), `synthetic_map_prices.csv`,
  `synthetic_inventory_planning_params_5y.csv`, `synthetic_material_fidelity_5y.csv`,
  `period_lookup_5y.csv`.
- **What each instance is.** A material's monthly demand series + its demand-pattern
  attributes (Syntetos–Boylan class, ADI, CV², zero fraction, run lengths, trend/level-shift
  flags) and its order-line participation.
- **Labels / structure preserved.** ~70% monthly zeros, ADI median ≈ 4, CV² median ≈ 2.5,
  ≈ 90% intermittent/lumpy, right-skewed nonzero sizes, multi-item orders, ≈ 20% cold-start,
  and real-like decline/obsolescence (≈ half the materials decline over their life).
- **No real data.** All identifiers/categories are tokenized neutral labels; MAP prices are
  drawn from a calibrated distribution (not real prices); demand values are synthetic
  surrogates, and a release audit verifies no released series is element-for-element
  identical to any real series (coincidental ultra-sparse collisions are perturbed).
  The synthetic→real source mapping is intentionally withheld. See `PRIVACY.md`.

## Collection / generation process (v2 — parametric)
- **Generator.** `generate_synthetic_replicable_dataset_v2.py` (+ `_inverse_cdf_families.py`),
  seed 42. Released for procedural transparency; like any masked surrogate it needs the
  confidential per-SKU parameter catalogue to *run*, but contains no real data itself.
- **Procedure.**
  1. **Template sampling.** Each synthetic material draws a real SKU's *aggregate* parameter
     template — best-fit count family (Poisson / NB / ZIP / ZINB / hurdle-NB / compound
     Poisson–gamma / compound Poisson–log-normal / 2-gamma mixture), the family's fitted
     parameters, zero fraction, non-zero mean and CV², and a platform — from an internal
     catalogue. Only aggregate per-SKU statistics are read; no real demand value is used.
  2. **Marginal (determinacy-routed).** Each material is drawn from its fitted distribution by
     **inverse-CDF** when the fit is well-determined (observations-per-parameter above a
     threshold), and from a moment-matched law otherwise — because a flexible family's MLE tail
     is unreliable when fit on few observations. A per-SKU empirical percentile bounds the tail.
  3. **Dependence.** A per-platform latent Gaussian occurrence factor makes same-platform
     materials co-occur, reproducing within-platform upper-tail dependence.
  4. **Non-stationarity.** Each material's test window is declined per the real SKU's
     first-half/second-half ratio, reproducing real decline/obsolescence.
  5. **Regenerate-until-fidelity.** Each material is regenerated (up to ten draws) until its
     realized signature (Syntetos–Boylan class, zero fraction; CV² scored) matches its
     template, else the best-scoring draw is kept; the outcome is recorded per material in
     `synthetic_material_fidelity_5y.csv`.
  6. **Release audit.** No released series may be element-for-element identical to any real
     series; a coincidental collision (possible for ultra-sparse patterns) is resolved by
     moving one occurrence within its window segment, preserving the audited statistics.
  - Multi-item orders, MAP prices, and inventory-planning parameters are synthesized on top;
    release window 48/60 train/test (the paper's industrial protocol uses 69/81).

## Fidelity certification (vs. the confidential real panel)
Audited with the same distribution-fit and copula fitters on the shared 60-month window:
- **Marginals.** Best-family-per-material mix total-variation distance **0.051** (zero-fraction
  median 0.729 vs. 0.750; dispersion index median 2.29 vs. 2.06).
- **Dependence.** Bivariate-copula tail dependence within ~0.01 (λ_U 0.116 vs. 0.107; λ_L 0.018
  vs. 0.029); copula-family mix TVD **0.068**; both panels weak, light-tailed (mean Spearman ρ
  0.06 vs. 0.04).
- **Decision behaviour.** The accuracy–service inversion reproduces strongly
  (full 38-method per-material Spearman ρ ≈ **−0.47** at the 80% target; n = 38, p < 0.005,
  95% CI [−0.76, −0.10] excludes zero; negative at every service level) — roughly 80% of the
  industrial panel's like-for-like **per-material** −0.58, far beyond the structural
  surrogate's −0.31, and confirming the benchmark preserves the phenomenon it is built to
  study. (The industrial panel's contract **order-level** value, computed over 20,330 real
  multi-item orders, is −0.555; the synthetic replication does not score that construct.)
- **Per-material audit.** `synthetic_material_fidelity_5y.csv` reports each material's
  distribution match to its source SKU (family, zero fraction, CV²); 73% pass the strict
  per-material criterion (the panel-level scores above are the primary comparator). The
  criterion is not adjusted for the ≈ 20% forced cold-start injection, which zeroes the
  training window after the target is fixed: 84% of non-cold-start materials pass, versus
  27% of cold-start materials, whose zero-fraction miss is the intended intervention.

## Intended uses
- Decision-aware forecasting evaluation (accuracy *and* order-level service under a policy).
- Foundation-model adaptation studies on sparse/intermittent demand.
- Intermittent-demand inventory-policy design under realistic (light) cross-material dependence.
- Bias-direction / occurrence-size diagnostics; cold-start transfer.
- Reproducing this paper's leaderboard, accuracy–service inversion, and the InstanceNorm fix.

## Limitations
- One industrial domain, monthly granularity; the 60-month release window is a subset of the
  real 81-month panel. Tail-dependence estimates are noisy at 60 periods (mean-over-pairs is the
  valid comparator). Bivariate copula screen only (per-platform vines out of scope). The
  accuracy–service inversion is regime-specific (heavy single-direction intermittency). The
  marginal family-mix match (TVD 0.051) is slightly looser than a perturb-from-real surrogate
  would give, the trade for a fully parametric generative model.

## Distribution / maintenance
- **License** CC-BY-4.0; integrity via `checksums.sha256`.
- **Contact** jooern.chin.2025@engd.smu.edu.sg.
- **Provenance of templates** withheld (confidential); generator + audit released for
  full procedural transparency.
